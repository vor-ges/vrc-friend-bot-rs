# PORTING.md — Python版 → Rust版 反映状況

元リポジトリ: https://github.com/vor-ges/vrc-friend-bot

## 現在の基準 (Rust版が追従しているPython版)

- 状態: **GitHubにコミット済み・基準確定** (2026-11-21 照合)
- コードの基準コミット: **`8addfa9`** "Track activity for all VRChat friends everytime"
  (bot.py / db.py / i18n.py / stats.py / vrc.py / test_local.py / requirements.txt / .env.example が `upstream/` と完全一致)
- 照合時点のmain先頭: `f417004` (8addfa9 と 7c6a016 のマージ。コード差分なし)
- 差異: `README.md` の末尾改行のみ (内容は同じ)
- Python版のバージョン表記: `1.2.1`

次回の差分取得は `git diff 8addfa9 origin/main` を起点にする。
スナップショット本体は `upstream/` にある (Rust版の反映後も消さないこと)。

## ファイルのSHA-256 (upstream/)

```
7aec2e5e22a52cd6ed3c157e7854d62a0b023fd9e058a90164ebd8d75783a828  bot.py
c8e4de1ad68d0facdd67b0e53869ad17060713fae2b5b2caa59247adf912f9d7  db.py
b0624eced99ed1b4b33b9f1c2194bcbfb0d565b92980076b3e046b5f6c1ee1f2  i18n.py
398f13ae90dea6d11697b4db3774a6d4785ca6d78dbe59a6c2ba12468b75e49f  stats.py
3842fe077fd2689c91a555c5bb92f12cc7c0be97010d70f74016c65313ee75d3  vrc.py
45b16f683b882814b62b02cb23e4882b7c39538a4241e4dc6d362cce4f75d210  test_local.py
8f8ac5156f5b4e16efaf0d5c607c2fc8919839d48e07b3c52a614d8b24404b7f  requirements.txt
78c88a49a0d187bf022d59970055d28bb72c7e1239762e90077a4b72b5f7ae5e  .env.example
f8045096e47179df08d681ef657b9f84a04d24bf37ff2398db21ab64c4d8c271  README.md
d148bebbe22dee80c3ca9c00a8e47df91adb5908701328b06156d6d03acc7913  README.ja.md
```

## 更新手順 (差分だけを反映する)

1. 最新のPython版を取得する (GitHubのclone、または最新のZip)
2. `upstream/` と比較し、変更されたファイル・行だけを抽出する
3. その変更に対応するRust側の関数・構造体だけを修正する (全面的な書き直しはしない)
4. 反映が済んだら `upstream/` を新しい版に置き換え、このファイルの
   「現在の基準」とSHA-256を更新する

## Python → Rust 対応表 (Rust実装時に埋める)

| Python | Rust | 状態 |
|---|---|---|
| `bot.py` | `src/bot.rs` | 未着手 |
| `db.py` | `src/db.rs` | 未着手 |
| `stats.py` | `src/stats.rs` | 未着手 |
| `vrc.py` | `src/vrc.rs` | 未着手 |
| `i18n.py` | `src/i18n.rs` | 未着手 |
| `test_local.py` | `tests/` | 未着手 |

DBスキーマ (`friends` / `activity` / `stats_meta` / `vrc_friends` / `bot_settings`) は
既存の `bot.db` と互換を保つ。
